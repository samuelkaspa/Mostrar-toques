package com.mostrartoques;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Surface;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class OverlayService extends Service {
    static volatile boolean running = false;
    static final String ACT_STOP = "stop";
    static final String ACT_RELOAD = "reload";
    private static final String CH = "touch_overlay";

    private WindowManager wm;
    private WebView web;
    private Thread reader;
    private volatile Process proc;
    private volatile boolean alive;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent != null ? intent.getAction() : null;
        if (ACT_STOP.equals(act)) { stopSelf(); return START_NOT_STICKY; }
        if (ACT_RELOAD.equals(act)) { if (web != null) loadPage(); return START_NOT_STICKY; }
        if (running) return START_NOT_STICKY;

        startFg();
        try {
            addOverlay();
        } catch (Throwable t) {
            toast("Sem permissão de sobreposição.");
            stopSelf();
            return START_NOT_STICKY;
        }
        running = true;
        startReader();
        return START_NOT_STICKY;
    }

    private void startFg() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "Mostrar Toques", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, OverlayService.class).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CH)
                .setContentTitle("Mostrar Toques ativo")
                .setContentText("Toque em PARAR para desligar")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "PARAR", stop)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else
            startForeground(1, n);
    }

    private void addOverlay() {
        wm = getSystemService(WindowManager.class);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(web, lp);
        loadPage();
    }

    private void loadPage() {
        String js = EditorActivity.currentJs(this);
        String html = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>html,body{margin:0;background:transparent;overflow:hidden}canvas{position:fixed;inset:0}</style></head><body>"
                + "<canvas id='c'></canvas>"
                + "<script>"
                + "var canvas=document.getElementById('c'),ctx=canvas.getContext('2d'),W=0,H=0,raf=0;"
                + "function fit(){var d=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;"
                + "canvas.width=W*d;canvas.height=H*d;ctx.setTransform(d,0,0,d,0,0);}"
                + "fit();addEventListener('resize',function(){fit();wake();});"
                + "function wake(){if(!raf)raf=requestAnimationFrame(loop);}"
                + "function loop(t){raf=0;ctx.clearRect(0,0,W,H);var more=false;"
                + "try{if(window.draw)more=window.draw(ctx,t,W,H);}catch(e){}if(more)wake();}"
                + "window.__t=function(id,type,fx,fy){try{if(window.onTouch)window.onTouch({id:id,type:type,x:fx*W,y:fy*H});}catch(e){}wake();};"
                + "</script><script>" + js + "\n</script></body></html>";
        web.loadDataWithBaseURL("https://localhost/", html, "text/html", "utf-8", null);
    }

    // ---------- leitura dos toques via Shizuku (getevent) ----------

    private Process sh(String cmd) throws Exception {
        Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        m.setAccessible(true);
        return (Process) m.invoke(null, new Object[]{new String[]{"sh", "-c", cmd}, null, null});
    }

    private void startReader() {
        alive = true;
        reader = new Thread(() -> {
            try {
                String[] info = detect();
                if (info == null) { toast("Não achei a tela de toque."); stopSelfUi(); return; }
                stream(info[0], Float.parseFloat(info[1]), Float.parseFloat(info[2]));
            } catch (Throwable t) {
                if (alive) { toast("Erro: " + t.getMessage()); stopSelfUi(); }
            }
        }, "touch-reader");
        reader.start();
    }

    private static final Pattern MAX = Pattern.compile("max\\s+(\\d+)");

    private static int parseMax(String line) {
        Matcher m = MAX.matcher(line);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }

    private String[] detect() throws Exception {
        Process p = sh("getevent -lp");
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line, dev = null;
        int mx = -1, my = -1;
        long bestArea = 0;
        String[] best = null;
        while ((line = r.readLine()) != null) {
            if (line.startsWith("add device")) {
                int i = line.indexOf("/dev");
                dev = i >= 0 ? line.substring(i).trim() : null;
                mx = my = -1;
            } else if (line.contains("ABS_MT_POSITION_X")) {
                mx = parseMax(line);
            } else if (line.contains("ABS_MT_POSITION_Y")) {
                my = parseMax(line);
                if (dev != null && mx > 0 && my > 0 && (long) mx * my > bestArea) {
                    bestArea = (long) mx * my;
                    best = new String[]{dev, String.valueOf(mx), String.valueOf(my)};
                }
            }
        }
        p.destroy();
        return best;
    }

    private void stream(String dev, float maxX, float maxY) throws Exception {
        proc = sh("exec getevent -l " + dev);
        BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream()));
        final int N = 20;
        float[] x = new float[N], y = new float[N];
        boolean[] act = new boolean[N], down = new boolean[N], up = new boolean[N], moved = new boolean[N];
        int cur = 0;
        String line;
        while (alive && (line = r.readLine()) != null) {
            String[] t = line.trim().split("\\s+");
            if (t.length < 3) continue;
            String code = t[t.length - 2], val = t[t.length - 1];
            switch (code) {
                case "ABS_MT_SLOT":
                    cur = (int) Long.parseLong(val, 16);
                    if (cur < 0 || cur >= N) cur = 0;
                    break;
                case "ABS_MT_TRACKING_ID":
                    if (val.equalsIgnoreCase("ffffffff")) { if (act[cur]) up[cur] = true; }
                    else { act[cur] = true; down[cur] = true; }
                    break;
                case "ABS_MT_POSITION_X": x[cur] = Long.parseLong(val, 16) / maxX; moved[cur] = true; break;
                case "ABS_MT_POSITION_Y": y[cur] = Long.parseLong(val, 16) / maxY; moved[cur] = true; break;
                case "SYN_REPORT": {
                    StringBuilder sb = null;
                    for (int i = 0; i < N; i++) {
                        String type = down[i] ? "down" : (up[i] ? "up" : (moved[i] && act[i] ? "move" : null));
                        if (type != null) {
                            if (sb == null) sb = new StringBuilder();
                            float fx = x[i], fy = y[i], ox = fx, oy = fy;
                            switch (rotation()) {
                                case Surface.ROTATION_90: ox = fy; oy = 1f - fx; break;
                                case Surface.ROTATION_180: ox = 1f - fx; oy = 1f - fy; break;
                                case Surface.ROTATION_270: ox = 1f - fy; oy = fx; break;
                                default: break;
                            }
                            sb.append("__t(").append(i).append(",'").append(type).append("',")
                                    .append(ox).append(',').append(oy).append(");");
                        }
                        if (up[i]) act[i] = false;
                        down[i] = up[i] = moved[i] = false;
                    }
                    if (sb != null) {
                        final String js = sb.toString();
                        ui.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
                    }
                    break;
                }
                default: break;
            }
        }
        if (alive) stopSelfUi();
    }

    @SuppressWarnings("deprecation")
    private int rotation() {
        try { return wm.getDefaultDisplay().getRotation(); } catch (Throwable t) { return 0; }
    }

    private void toast(String s) { ui.post(() -> Toast.makeText(this, s, Toast.LENGTH_LONG).show()); }
    private void stopSelfUi() { ui.post(this::stopSelf); }

    @Override
    public void onDestroy() {
        alive = false;
        running = false;
        try { if (proc != null) proc.destroy(); } catch (Throwable ignored) {}
        if (reader != null) reader.interrupt();
        try { if (web != null) { wm.removeView(web); web.destroy(); web = null; } } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
