# Mostrar Toques

App Android que mostra um efeito de toque em qualquer lugar da tela, por cima de todos os apps, rodando em segundo plano.
O efeito é um arquivo JS que você edita (`app/src/main/assets/touch.js`, ou pelo botão **Editar JS** dentro do app, sem recompilar).

## Gerar o APK
1. Suba esta pasta inteira para um repositório no GitHub.
2. Aba **Actions** → **Build APK** → o build roda sozinho (ou **Run workflow**).
3. Ao terminar, baixe o artefato **MostrarToques-apk**, extraia e instale o `.apk`.

## Usar
1. Instale o **Shizuku** (Play Store) e inicie: Opções do desenvolvedor → Depuração sem fio → no Shizuku, "Iniciar via Depuração sem fio" (precisa refazer após reiniciar o celular).
2. Abra o **Mostrar Toques** → passo 1 (sobreposição) → passo 2 (autorizar Shizuku) → **PLAY**.
3. Para parar: botão **PARAR** no app ou na notificação.

## API do JS
- `onTouch(e)` — `e = { id, type: 'down'|'move'|'up', x, y }` (pixels).
- `draw(ctx, now, W, H)` — desenha o frame; retorne `true` para continuar animando, `false` para parar (parado = 0% de CPU).
