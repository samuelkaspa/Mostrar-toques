// ===== touch.js — EDITE À VONTADE (pelo botão "Editar JS" no app) =====
// onTouch(e): chamado a cada toque. e = { id, type: 'down' | 'move' | 'up', x, y }  (x,y em pixels)
// draw(ctx, now, W, H): desenha cada frame. Retorne true para continuar animando,
//                       false para parar (parado = 0% de CPU).

const rings = [];
const fingers = {};
const DURATION = 550;   // ms do anel
const MAX_R = 54;       // raio máximo do anel
const HOLD_R = 26;      // raio do círculo enquanto o dedo está na tela
const COLOR = '96,165,250';

function onTouch(e) {
  if (e.type === 'down') {
    fingers[e.id] = { x: e.x, y: e.y };
    rings.push({ x: e.x, y: e.y, t: performance.now() });
  } else if (e.type === 'move') {
    const f = fingers[e.id];
    if (f) { f.x = e.x; f.y = e.y; }
  } else {
    delete fingers[e.id];
  }
}

function draw(ctx, now) {
  for (let i = rings.length - 1; i >= 0; i--) {
    const r = rings[i];
    const p = (now - r.t) / DURATION;
    if (p >= 1) { rings.splice(i, 1); continue; }
    const ease = 1 - Math.pow(1 - p, 3);
    ctx.beginPath();
    ctx.arc(r.x, r.y, HOLD_R * 0.5 + (MAX_R - HOLD_R * 0.5) * ease, 0, Math.PI * 2);
    ctx.lineWidth = 3 * (1 - p) + 0.5;
    ctx.strokeStyle = 'rgba(' + COLOR + ',' + (0.9 * (1 - p)).toFixed(3) + ')';
    ctx.stroke();
  }
  for (const id in fingers) {
    const f = fingers[id];
    ctx.beginPath();
    ctx.arc(f.x, f.y, HOLD_R, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(' + COLOR + ',0.35)';
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(255,255,255,0.75)';
    ctx.stroke();
  }
  return rings.length > 0 || Object.keys(fingers).length > 0;
}
