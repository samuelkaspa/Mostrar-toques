package com.mostrartoques;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private TextView status;
    private Button toggle;
    private final Shizuku.OnRequestPermissionResultListener permListener =
            (code, result) -> runOnUiThread(this::refresh);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0b0d12"));
        root.setPadding(48, 96, 48, 48);

        TextView title = new TextView(this);
        title.setText("Mostrar Toques");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        status = new TextView(this);
        status.setTextColor(Color.parseColor("#9aa3b8"));
        status.setTextSize(15);
        status.setPadding(0, 32, 0, 32);
        root.addView(status);

        root.addView(btn("1. Permitir sobreposição (aparecer sobre apps)", v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }));

        root.addView(btn("2. Permitir Shizuku", v -> {
            if (!shizukuRunning()) {
                Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (i != null) startActivity(i);
                else toast("Instale e inicie o Shizuku primeiro (veja o README).");
                return;
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                toast("Permissão negada. Libere em Shizuku → Apps autorizados.");
                return;
            }
            Shizuku.requestPermission(1);
        }));

        toggle = btn("▶ PLAY", v -> {
            if (OverlayService.running) {
                startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACT_STOP));
                v.postDelayed(this::refresh, 400);
                return;
            }
            if (!Settings.canDrawOverlays(this)) { toast("Falta o passo 1."); return; }
            if (!shizukuOk()) { toast("Falta o passo 2 (Shizuku)."); return; }
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
            }
            startForegroundService(new Intent(this, OverlayService.class));
            v.postDelayed(this::refresh, 600);
        });
        toggle.setBackgroundColor(Color.parseColor("#3b82f6"));
        root.addView(toggle);

        root.addView(btn("✎ Editar JS", v -> startActivity(new Intent(this, EditorActivity.class))));

        setContentView(root);
        try { Shizuku.addRequestPermissionResultListener(permListener); } catch (Throwable ignored) {}
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#1c2230"));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 160);
        lp.setMargins(0, 0, 0, 24);
        b.setLayoutParams(lp);
        b.setGravity(Gravity.CENTER);
        return b;
    }

    private boolean shizukuRunning() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    private boolean shizukuOk() {
        try {
            return Shizuku.pingBinder()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) { return false; }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private void refresh() {
        boolean ov = Settings.canDrawOverlays(this);
        boolean sr = shizukuRunning();
        boolean so = shizukuOk();
        status.setText(
                (ov ? "✅" : "❌") + " Sobreposição\n" +
                (sr ? "✅" : "❌") + " Shizuku rodando\n" +
                (so ? "✅" : "❌") + " Shizuku autorizado\n\n" +
                (OverlayService.running ? "Efeito ATIVO em segundo plano." : "Efeito parado."));
        toggle.setText(OverlayService.running ? "■ PARAR" : "▶ PLAY");
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    @Override protected void onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permListener); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
