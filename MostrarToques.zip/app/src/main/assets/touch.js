// ===== touch.js — EDITE À VONTADE =====
// Bola: lado DIREITO da tela = azul, lado ESQUERDO = vermelho.
// Só tocar e soltar: a bola some aos poucos.
// Tocar e arrastar: mostra um rastro.
// Tocar e segurar parado: mostra o tempo com decimais dentro da bola.

const BLUE = '59,130,246';
const RED = '239,68,68';
const R = 30;              // raio da bola
const FADE = 700;          // ms para a bola sumir depois de soltar
const TRAIL_LIFE = 450;    // ms de vida de cada ponto do rastro
const MOVE_MIN = 14;       // px que precisa mexer para virar "arrastar"
const HOLD_SHOW = 250;     // ms segurando para aparecer o tempo

const touches = {};        // toques ativos, por id
const dead = [];           // toques já soltos (sumindo)

function onTouch(e) {
  const now = performance.now();
  if (e.type === 'down') {
    touches[e.id] = {
      x: e.x, y: e.y, sx: e.x, sy: e.y, t0: now, tUp: 0,
      color: e.x > innerWidth / 2 ? BLUE : RED,
      moved: false, trail: [{ x: e.x, y: e.y, t: now }], holdMs: 0
    };
  } else if (e.type === 'move') {
    const t = touches[e.id];
    if (!t) return;
    t.x = e.x; t.y = e.y;
    if (!t.moved && Math.hypot(t.x - t.sx, t.y - t.sy) > MOVE_MIN) t.moved = true;
    if (t.moved) {
      const last = t.trail[t.trail.length - 1];
      if (Math.hypot(t.x - last.x, t.y - last.y) > 2) t.trail.push({ x: t.x, y: t.y, t: now });
    }
  } else {
    const t = touches[e.id];
    if (!t) return;
    t.tUp = now;
    if (!t.moved) t.holdMs = now - t.t0;
    delete touches[e.id];
    dead.push(t);
  }
}

function drawTrail(ctx, t, now, mul) {
  const p = t.trail;
  while (p.length && now - p[0].t > TRAIL_LIFE) p.shift();
  ctx.lineCap = 'round';
  ctx.lineWidth = R * 0.9;
  for (let i = 1; i < p.length; i++) {
    const a = (1 - (now - p[i].t) / TRAIL_LIFE) * mul * 0.7;
    if (a <= 0) continue;
    ctx.beginPath();
    ctx.moveTo(p[i - 1].x, p[i - 1].y);
    ctx.lineTo(p[i].x, p[i].y);
    ctx.strokeStyle = 'rgba(' + t.color + ',' + a.toFixed(3) + ')';
    ctx.stroke();
  }
}

function drawBall(ctx, t, now, alpha, ms) {
  ctx.beginPath();
  ctx.arc(t.x, t.y, R, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(' + t.color + ',' + (0.85 * alpha).toFixed(3) + ')';
  ctx.fill();
  ctx.lineWidth = 3;
  ctx.strokeStyle = 'rgba(255,255,255,' + alpha.toFixed(3) + ')';
  ctx.stroke();
  if (ms !== null) {
    ctx.fillStyle = 'rgba(255,255,255,' + alpha.toFixed(3) + ')';
    ctx.font = 'bold 15px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText((ms / 1000).toFixed(2) + 's', t.x, t.y);
  }
}

function draw(ctx, now) {
  for (let i = dead.length - 1; i >= 0; i--) {
    const t = dead[i];
    const p = (now - t.tUp) / FADE;
    if (p >= 1) { dead.splice(i, 1); continue; }
    const a = 1 - p;
    drawTrail(ctx, t, now, a);
    drawBall(ctx, t, now, a, t.holdMs > HOLD_SHOW ? t.holdMs : null);
  }
  for (const id in touches) {
    const t = touches[id];
    drawTrail(ctx, t, now, 1);
    const held = now - t.t0;
    drawBall(ctx, t, now, 1, (!t.moved && held > HOLD_SHOW) ? held : null);
  }
  return dead.length > 0 || Object.keys(touches).length > 0;
}
