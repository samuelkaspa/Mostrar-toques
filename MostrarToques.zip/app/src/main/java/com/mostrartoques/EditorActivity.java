package com.mostrartoques;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class EditorActivity extends Activity {
    private EditText edit;

    static String defaultJs(android.content.Context c) throws Exception {
        try (InputStream in = c.getAssets().open("touch.js")) { return readAll(in); }
    }

    static String currentJs(android.content.Context c) {
        try {
            File f = new File(c.getFilesDir(), "touch.js");
            if (f.exists()) try (InputStream in = new java.io.FileInputStream(f)) { return readAll(in); }
            return defaultJs(c);
        } catch (Exception e) { return ""; }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        return o.toString("UTF-8");
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0b0d12"));
        root.setPadding(24, 72, 24, 24);

        edit = new EditText(this);
        edit.setText(currentJs(this));
        edit.setTypeface(Typeface.MONOSPACE);
        edit.setTextSize(12);
        edit.setTextColor(Color.parseColor("#e8ecf5"));
        edit.setBackgroundColor(Color.parseColor("#141925"));
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setHorizontallyScrolling(true);
        edit.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        root.addView(edit, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout row = new LinearLayout(this);
        Button save = new Button(this);
        save.setText("Salvar");
        save.setOnClickListener(v -> {
            try (FileOutputStream o = new FileOutputStream(new File(getFilesDir(), "touch.js"))) {
                o.write(edit.getText().toString().getBytes("UTF-8"));
            } catch (Exception e) { Toast.makeText(this, "Erro: " + e, Toast.LENGTH_LONG).show(); return; }
            if (OverlayService.running)
                startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACT_RELOAD));
            Toast.makeText(this, "Salvo!", Toast.LENGTH_SHORT).show();
        });
        Button reset = new Button(this);
        reset.setText("Restaurar padrão");
        reset.setOnClickListener(v -> {
            new File(getFilesDir(), "touch.js").delete();
            edit.setText(currentJs(this));
            if (OverlayService.running)
                startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACT_RELOAD));
        });
        row.addView(save, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(reset, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(row);
        setContentView(root);
    }
}
